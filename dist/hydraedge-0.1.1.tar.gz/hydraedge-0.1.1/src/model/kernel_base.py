
# LinkerKernel.forward(e_src,e_dst)